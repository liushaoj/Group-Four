#include <stdio.h>  
#include <stdlib.h>  
#include <string.h>  
#include <unistd.h>  
#include <sys/wait.h>  
  
#define BUFFER_SIZE 1024  
  


int main() {  
    char buffer[BUFFER_SIZE];  
    char *args[BUFFER_SIZE / 2]; // 假设参数数量不会超过BUFFER_SIZE/2  
    int argc;  
  
    printf("mytools ");  
  
    while (1) {  
        // 读取用户输入的命令  
        if (fgets(buffer, BUFFER_SIZE, stdin) == NULL) {  
            perror("fgets failed");  
            break;  
        }  
  
        // 去除换行符  
        buffer[strcspn(buffer, "\n")] = 0;  
  
        // 解析输入字符串为参数数组  
        argc = 0;  
        args[argc++] = strtok(buffer, " \t\n");  
  
        while (argc < BUFFER_SIZE / 2 && (args[argc++] = strtok(NULL, " \t\n")) != NULL) {  
            // 继续解析参数  
        }  
  
        if (argc == 0) {  
            // 如果没有输入任何内容，则跳过  
            continue;  
        }  
  
        // 创建子进程  
        pid_t pid = fork();  // 修正这里  
  
        if (pid == -1) {  
            perror("fork failed");  
            continue;  
        }  
  
        // 子进程逻辑  
        if (pid == 0) {  
        // 打印要执行的命令  
        printf("Executing: %s\n", args[0]);  
  
        // 使用 execvp 执行命令  
        execvp(args[0], args);  
  
        // 如果 execvp 返回，说明有错误  
        perror("execvp failed");  
        _exit(EXIT_FAILURE);  
    } 
  
        // 父进程逻辑  
        int status;  
        if (waitpid(pid, &status, 0) == -1) {  
 
           perror("waitpid failed");  
            continue;  
        }  
  
        if (WIFEXITED(status)) {  
            printf("Child exited with status %d\n", WEXITSTATUS(status));  
        } else if (WIFSIGNALED(status)) {  
            printf("Child killed by signal %d\n", WTERMSIG(status));  
        }  
  
        printf("mytools "); // 提示用户再次输入  
    }  
  
    return 0;  
}
