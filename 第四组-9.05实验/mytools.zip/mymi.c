#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>

#define BUFFER_SIZE 1024

int main(int argc, char *argv[]) {
    char buffer[BUFFER_SIZE];
    ssize_t bytesRead;
    int fd;
    // 鎵撳紑 /proc/meminfo 鏂囦欢
    fd = open("/proc/meminfo", O_RDONLY);
    if (fd == -1) {
        perror("Error opening /proc/meminfo");
        return EXIT_FAILURE;
    }
    // 閫愯璇诲彇鏂囦欢鍐呭骞舵墦鍗?
    while ((bytesRead = read(fd, buffer, BUFFER_SIZE - 1)) > 0) {
        buffer[bytesRead] = '\0';  // 纭繚瀛楃涓蹭互null缁堟
        char *line = strtok(buffer, "\n");  
        while (line != NULL) {  
            if (strstr(line, "MemTotal:") != NULL || strstr(line, "MemFree:") != NULL || strstr(line, "MemAvailable:") != NULL || strstr(line, "Buffers:") != NULL || strstr(line ,"Cached:")            != NULL || strstr(line, "SwapCached:") != NULL || strstr(line, "SwapTotal:") != NULL || strstr(line, "SwapFree:") != NULL){ 

                printf("%s\n", line);  
            }  
            // 缁х画鑾峰彇涓嬩竴琛? 
            line = strtok(NULL, "\n");
        }  
    }
    // 妫€鏌ヨ鍙栭敊璇?
    if (bytesRead == -1) {
        perror("Error reading from /proc/meminfo");
        close(fd);
        return EXIT_FAILURE;
    }
    // 鍏抽棴鏂囦欢鎻忚堪绗?
    close(fd);
    return EXIT_SUCCESS;
}
