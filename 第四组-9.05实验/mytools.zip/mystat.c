#include <stdio.h>  
#include <stdlib.h>  
#include <sys/stat.h>  
#include <sys/types.h>  
#include <unistd.h>  
#include <string.h>  
#include <pwd.h>  
#include <grp.h>
  
void printStatInfo(const struct stat *buf, const char *filename);  
int main(int argc, char *argv[]) {  
    struct stat fileInfo;  
    int result;  
    if (argc != 2) {  
        fprintf(stderr, "Usage: %s <filename>\n", argv[0]);  
        return EXIT_FAILURE;  
    }  
    result = stat(argv[1], &fileInfo);  
    if (result == -1) {  
        perror("Error getting file status");  
        return EXIT_FAILURE;  
    }  
    printStatInfo(&fileInfo, argv[1]);  
    return EXIT_SUCCESS;    
}
  
void printStatInfo(const struct stat *buf, const char *filename) {  
    const char *username = "unknown";  
    const char *groupname = "unknown";  
    struct passwd *pw = getpwuid(buf->st_uid);  
    if (pw != NULL) {  
        username = pw->pw_name;  
    }  
    struct group *gr = getgrgid(buf->st_gid);  
    if (gr != NULL) {  
        groupname = gr->gr_name;  
    }  
    char perms[11] = {0};   
    printf("File: '%s'\n", filename);  
    printf("Size: %ld bytes\n", (long)buf->st_size);  
    printf("Inode: %lu\n", (unsigned long)buf->st_ino);  
    printf("Type: ");  
    switch (buf->st_mode & S_IFMT) {  
       case S_IFREG:
            printf("regular\n");
            break;
        case S_IFDIR:
            printf("directory\n");
            break;
        case S_IFCHR:
            printf("character device\n");
            break;
        case S_IFBLK:
            printf("block device\n");
            break;
        case S_IFIFO:
            printf("fifo/pipe\n");
            break;
        case S_IFLNK:
            printf("symbolic link\n");
            break;
        case S_IFSOCK:
            printf("socket\n");
            break;
        default:
            printf("unknown\n");
            break;
    }    
    printf("Links: %ld\n", (long)buf->st_nlink);  
    printf("UID: %ld (%s)\n", (long)buf->st_uid, username);  
    printf("GID: %ld (%s)\n", (long)buf->st_gid, groupname);    
    switch (buf->st_mode & S_IFMT) {  
        case S_IFDIR:  
            perms[0] = 'd';  
            break;  
        case S_IFREG:  
            perms[0] = '-';  
            break;  
    }  
    int i = 1; 
    if (buf->st_mode & S_IRUSR) perms[i++] = 'r'; else perms[i++] = '-';  
    if (buf->st_mode & S_IWUSR) perms[i++] = 'w'; else perms[i++] = '-';  
    if (buf->st_mode & S_IXUSR) perms[i++] = 'x'; else perms[i++] = '-';  
    if (buf->st_mode & S_IRGRP) perms[i++] = 'r'; else perms[i++] = '-';  
    if (buf->st_mode & S_IWGRP) perms[i++] = 'w'; else perms[i++] = '-';  
    if (buf->st_mode & S_IXGRP) perms[i++] = 'x'; else perms[i++] = '-';  
    if (buf->st_mode & S_IROTH) perms[i++] = 'r'; else perms[i++] = '-';  
    if (buf->st_mode & S_IWOTH) perms[i++] = 'w'; else perms[i++] = '-';  
    if (buf->st_mode & S_IXOTH) perms[i++] = 'x'; else perms[i++] = '-';    
    perms[i] = '\0';  
    char perms_octal[5];  
    sprintf(perms_octal, "%04o", (buf->st_mode & 0777));    
    printf("Access: (%s|%s)\n", perms_octal, perms);  
}
