#include <stdio.h>  
#include <stdlib.h>  
#include <string.h>  
#include <sys/types.h>  
#include <sys/stat.h>  
#include <fcntl.h>  
#include <unistd.h>  
  
#define BUFFER_SIZE 4096   
  
int main(int argc, char *argv[]) {  
    char *sourceFile, *destFile;  
    char buffer[BUFFER_SIZE];  
    ssize_t nread;  
    int inFile, outFile;  
  
    // 检查命令行参数数量  
    if (argc != 3) {  
        fprintf(stderr, "Usage: %s <source file> <destination file>\n", argv[0]);  
        return EXIT_FAILURE;  
    }  
  
    sourceFile = argv[1];  
    destFile = argv[2];  
  
    // 打开源文件  
    inFile = open(sourceFile, O_RDONLY);  
    if (inFile == -1) {  
        perror("Failed to open source file");  
        return EXIT_FAILURE;  
    }  
  
    // 打开或创建目标文件（如果目标文件已存在，则覆盖）  
    outFile = open(destFile, O_WRONLY | O_CREAT | O_TRUNC, S_IRUSR | S_IWUSR | S_IRGRP | S_IWGRP);  
    if (outFile == -1) {  
        perror("Failed to open or create destination file");  
        close(inFile);  
        return EXIT_FAILURE;  
    }  
  
    // 读写循环  
    while ((nread = read(inFile, buffer, BUFFER_SIZE)) > 0) {  
        if (write(outFile, buffer, nread) != nread) {  
            perror("Failed to write to destination file");  
            close(inFile);  
            close(outFile);  
            return EXIT_FAILURE;  
        }  
    }  
  
    // 检查 read 的返回值以处理文件末尾或错误  
    if (nread == -1) {  
        perror("Error reading from source file");  
        close(inFile);  
        close(outFile);  
        return EXIT_FAILURE;  
    }  
  
    // 关闭文件描述符  
    close(inFile);  
    close(outFile);  
  
    return EXIT_SUCCESS;  
}
