#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdio.h>
#include <dirent.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
    DIR *dir_ptr;
    struct dirent *direntp;
    struct stat statbuf;

    // 检查命令行参数数量
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <directory>\n", argv[0]);
        return 1;
    }

    // 尝试打开目录
    if ((dir_ptr = opendir(argv[1])) == NULL) {
        perror("Cannot open directory");
        return 1;
    }

    // 遍历目录
    while ((direntp = readdir(dir_ptr)) != NULL) {
        char filepath[1024];

        // 跳过 "." 和 ".."
        if (strcmp(direntp->d_name, ".") == 0 || strcmp(direntp->d_name, "..") == 0)
            continue;

        // 构造完整路径
        snprintf(filepath, sizeof(filepath), "%s/%s", argv[1], direntp->d_name);

        // 获取文件状态
        if (stat(filepath, &statbuf) == -1) {
            perror("stat");
            continue;
        }

        // 确定文件类型
        char filetype;
        switch (statbuf.st_mode & S_IFMT) {
            case S_IFDIR:
                filetype = 'd';
                break;
            case S_IFCHR:
                filetype = 'c';
                break;
            case S_IFBLK:
                filetype = 'b';
                break;
            case S_IFLNK:
                filetype = 'l';
                break;
            case S_IFREG:
            default:
                filetype = '-';
                break;
        }

        // 假设st_size可以安全地作为unsigned long long处理
        // 注意：这取决于你的系统和编译器
        unsigned long long filesize = (unsigned long long)statbuf.st_size;

        // 格式化文件大小（简单示例，没有千分位分隔符）
        char filesize_str[21]; // 假设文件大小不会超过2^64-1的十进制表示长度
        snprintf(filesize_str, sizeof(filesize_str), "%llu", filesize);

        // 输出inode、文件类型、UID、GID、文件大小和文件名
        printf("%11ld\t%c\t\tUID: %d\tGID: %d\t%s\t%s\n",
               statbuf.st_ino, filetype, statbuf.st_uid, statbuf.st_gid, filesize_str, direntp->d_name);
    }

    // 关闭目录
    closedir(dir_ptr);

    return 0;
}
